//
//  FavoritingPage.swift
//  MedTermIT
//
//  Created by Hamzah Hamad on 6/3/17.
//  Copyright © 2017 Integral6. All rights reserved.
//

import Foundation
import UIKit

class User: NSObject {
    
    
    var Term: String?
    var Definition: String?
    var Types: String?
    var Link:String?
    var Video:String?

}
