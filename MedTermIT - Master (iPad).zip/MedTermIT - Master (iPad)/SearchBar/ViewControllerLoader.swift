//
//  ViewControllerLoader.swift
//  MedTermIT
//
//  Created by Hamzah on 3/9/17.
//  Copyright © 2017 Integral6. All rights reserved.
//

import UIKit

class ViewControllerLoader: UIViewController {
    
    @IBOutlet weak var FirstCircle: UIImageView!
    @IBOutlet weak var SecondCircle: UIImageView!
    @IBOutlet weak var ThirdCircle: UIImageView!
    @IBOutlet weak var FourthCircle: UIImageView!
    @IBOutlet weak var FifthCircle: UIImageView!
    
    @IBOutlet weak var CircleStack: UIStackView!
    @IBOutlet weak var MedText: UILabel!
    @IBOutlet weak var loaderBackG: UIImageView!


    override func viewDidLoad() {
        super.viewDidLoad()
        FirstCircle.image = #imageLiteral(resourceName: "BlackCircle1")
        SecondCircle.image = #imageLiteral(resourceName: "BlackCircle1")
        ThirdCircle.image = #imageLiteral(resourceName: "BlackCircle1")
        FourthCircle.image = #imageLiteral(resourceName: "BlackCircle1")
        FifthCircle.image = #imageLiteral(resourceName: "BlackCircle1")
        
        Timer.scheduledTimer(timeInterval: 0.1, target: self, selector: #selector(firstCir), userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval: 0.6, target: self, selector: #selector(secCir), userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval: 1.2, target: self, selector: #selector(thirdCir), userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval: 1.8, target: self, selector: #selector(fourthCir), userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval: 2.4, target: self, selector: #selector(FifthCir), userInfo: nil, repeats: false)
        Timer.scheduledTimer(timeInterval: 2.6, target: self, selector: #selector(timeToMoveOn), userInfo: nil, repeats: false)

       
        
        
        
       
        
        CircleStack.center.x = view.center.x
        CircleStack.center.y = view.center.y
        MedText.center.x = view.center.x
        MedText.center.y = view.center.y - 100
        // Do any additional setup after loading the view.
    }
      
    func firstCir() {
        
        FirstCircle.image = #imageLiteral(resourceName: "GreyCirlcle1")
    
    }
    
    func secCir() {
        
        SecondCircle.image = #imageLiteral(resourceName: "GreyCirlcle1")
        
    }
    
    func thirdCir() {
        
        ThirdCircle.image = #imageLiteral(resourceName: "GreyCirlcle1")
        
    }
    
    func fourthCir() {
        
        FourthCircle.image = #imageLiteral(resourceName: "GreyCirlcle1")
        
    }
    func FifthCir() {
        
        FifthCircle.image = #imageLiteral(resourceName: "GreyCirlcle1")
        
    }
    
    func timeToMoveOn() {
        self.performSegue(withIdentifier: "goToMainUI", sender: self)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

