//
//  Bookmarks.swift
//  MockApp
//
//  Created by Hamzah Hamad on 5/15/17.
//  Copyright © 2017 Integral6. All rights reserved.
//

import Foundation
import UIKit

enum selectedScope5:Int {
    case Types = 2
}

class Bookmarks: UITableViewController {
    
    
    let searchBar = UISearchBar()
    
    let initialDataAry:[Model] = Model.generateModelArray()
    var dataAry:[Model] = Model.generateModelArray()
    var FavrtAry: [Model] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for var i in 0..<Model.StaticVal.favouriteArray.count {
            if(Model.StaticVal.favouriteArray[i] == 1)
            {
                FavrtAry.append(dataAry[i])
            }
        }
        

       
        

        //        self.searchBarSetup()
        //        filterTableView(ind: searchBar.selectedScopeButtonIndex, text: "Japan" )
        //        self.FavrtAry.sort(by: { $0.imageTerm < $1.imageTerm })
        
        
    }
    
    //    func searchBarSetup() {
    //        searchBar.selectedScopeButtonIndex = 2
    //    }
    
    
    //    func filterTableView(ind: Int, text: String) {
    //        switch ind {
    //        case selectedScope2.Types.rawValue:
    //            //fix of not searching when backspacing
    //            dataAry = initialDataAry.filter({ (mod) -> Bool in
    //                return mod.imageTypes.lowercased().contains(text.lowercased())
    //            })
    //            self.tableView.reloadData()
    //        default:
    //            print("no type")
    //        }
    //    }
    
    
    //    override var preferredStatusBarStyle: UIStatusBarStyle {
    //        return .lightContent
    //    }
    
    
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        //        var FavrtCount = 0
        //
        //            for var i in 0..<Model.StaticVal.favouriteArray.count {
        //            if(Model.StaticVal.favouriteArray[i] == 1)
        //            {
        //                FavrtCount += 1
        //            }
        //        }
        return FavrtAry.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath) as! TableViewCell1
        
        let model = FavrtAry[indexPath.row]
        
        cell.TermLbl.text = model.imageTerm
        cell.TypesLbl.text = model.imageTypes
        cell.DefinitionLbl.text = model.imageDefinition
        
        
        
        return cell
    }
    
    //add delegate method for pushing to new detail controller
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        vc.dataModel = FavrtAry[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    
    
}
