//
//  VideoPlayer.swift
//  MedTermIT
//
//  Created by Hamzah Hamad on 5/25/17.
//  Copyright © 2017 Integral6. All rights reserved.
//

import Foundation
import UIKit
import AVKit
import AVFoundation
import MediaPlayer
var moviePlayer : MPMoviePlayerController!


class VideoPlayer: UIViewController {
    
    @IBOutlet weak var SkipBut: UIButton!
    @IBOutlet weak var DontShowBut: UIButton!
    @IBOutlet weak var videoView: UIView!
    
    var player: AVPlayer!
    var avpController = AVPlayerViewController()
    var moviePlayer : MPMoviePlayerController!

    
    @IBAction func DontShow(_ sender: Any) {
        
        let userdefult = UserDefaults.standard
        
        userdefult.set("Dont", forKey: "SavedDont")
        userdefult.synchronize()
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoadingScreen") as! ViewControllerLoader
        self.navigationController?.pushViewController(vc, animated: false)

    }
    
    @IBAction func StopPlayandSkip(_ sender: Any) {
        
        self.player.replaceCurrentItem(with: nil)
        
    }
    
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        self.navigationController?.isNavigationBarHidden = true

        self.navigationItem.leftBarButtonItem = nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if self.view.frame.maxY == 667 {
            
            
            SkipBut.center.x = self.view.center.x
            SkipBut.center.y = 530
            DontShowBut.center.y = 590
            DontShowBut.center.x = self.view.center.x
            
            let moviePath = Bundle.main.path(forResource: "MedTerIt", ofType: "mp4")
            
            
            if let path = moviePath{
                let url = AVPlayer(url: URL(fileURLWithPath: path))
                
                self.player = AVPlayer(url: URL(fileURLWithPath: path))
                self.avpController = AVPlayerViewController()
                self.avpController.player = self.player
                avpController.view.frame.size.width = 375
                avpController.view.frame.size.height = 271
                avpController.view.center = self.view.center
                self.addChildViewController(avpController)
                self.view.addSubview((avpController.view)!)
                self.player.play()
            }

            
        } else if self.view.frame.maxY == 568 {
            
            SkipBut.center.x = self.view.center.x
            SkipBut.center.y = 460
            DontShowBut.center.y = 520
            DontShowBut.center.x = self.view.center.x
            
            let moviePath = Bundle.main.path(forResource: "MedTerIt", ofType: "mp4")
            
            
            if let path = moviePath{
                let url = AVPlayer(url: URL(fileURLWithPath: path))
                
                self.player = AVPlayer(url: URL(fileURLWithPath: path))
                self.avpController = AVPlayerViewController()
                self.avpController.player = self.player
                avpController.view.frame.size.width = 320
                avpController.view.frame.size.height = 271
                avpController.view.center = self.view.center
                self.addChildViewController(avpController)
                self.view.addSubview((avpController.view)!)
                self.player.play()
            }
            
        } else if self.view.frame.maxY == 736 {
            
            
            SkipBut.center.x = self.view.center.x
            SkipBut.center.y = 604
            DontShowBut.center.y = 664
            DontShowBut.center.x = self.view.center.x
            
            let moviePath = Bundle.main.path(forResource: "MedTerIt", ofType: "mp4")
            
            
            if let path = moviePath{
                let url = AVPlayer(url: URL(fileURLWithPath: path))
                
                self.player = AVPlayer(url: URL(fileURLWithPath: path))
                self.avpController = AVPlayerViewController()
                self.avpController.player = self.player
                avpController.view.frame.size.width = 414
                avpController.view.frame.size.height = 301
                avpController.view.center = self.view.center
                self.addChildViewController(avpController)
                self.view.addSubview((avpController.view)!)
                self.player.play()
            }

            
        } else if self.view.frame.maxY == 1112 {
            
            SkipBut.center.x = self.view.center.x
            SkipBut.center.y = 928
            DontShowBut.center.y = 1007
            DontShowBut.center.x = self.view.center.x
            
            let moviePath = Bundle.main.path(forResource: "MedTerIt", ofType: "mp4")
            
            
            if let path = moviePath{
                let url = AVPlayer(url: URL(fileURLWithPath: path))
                
                self.player = AVPlayer(url: URL(fileURLWithPath: path))
                self.avpController = AVPlayerViewController()
                self.avpController.player = self.player
                avpController.view.frame.size.width = 834
                avpController.view.frame.size.height = 633
                avpController.view.center = self.view.center
                self.addChildViewController(avpController)
                self.view.addSubview((avpController.view)!)
                self.player.play()
            }
            
        } else if self.view.frame.maxY == 1366 {
            
            SkipBut.center.x = self.view.center.x
            SkipBut.center.y = 1200
            DontShowBut.center.y = 1294
            DontShowBut.center.x = self.view.center.x
            

            let moviePath = Bundle.main.path(forResource: "MedTerIt", ofType: "mp4")
            
            
            if let path = moviePath{
                let url = AVPlayer(url: URL(fileURLWithPath: path))
                
                self.player = AVPlayer(url: URL(fileURLWithPath: path))
                self.avpController = AVPlayerViewController()
                self.avpController.player = self.player
                avpController.view.frame.size.width = 1024
                avpController.view.frame.size.height = 775
                avpController.view.center = self.view.center
                self.addChildViewController(avpController)
                self.view.addSubview((avpController.view)!)
                self.player.play()
            }
            
        } else if self.view.frame.maxY == 1024 {
            
            SkipBut.center.x = self.view.center.x
            SkipBut.center.y = 861
            DontShowBut.center.y = 952
            DontShowBut.center.x = self.view.center.x

            let moviePath = Bundle.main.path(forResource: "MedTerIt", ofType: "mp4")
            
            
            if let path = moviePath{
                let url = AVPlayer(url: URL(fileURLWithPath: path))
                
                self.player = AVPlayer(url: URL(fileURLWithPath: path))
                self.avpController = AVPlayerViewController()
                self.avpController.player = self.player
                avpController.view.frame.size.width = 768
                avpController.view.frame.size.height = 589
                avpController.view.center = self.view.center
                self.addChildViewController(avpController)
                self.view.addSubview((avpController.view)!)
                self.player.play()
            }
            
        } else {
            
            
            SkipBut.center.x = self.view.center.x
            SkipBut.center.y = self.view.frame.maxY - 100
            DontShowBut.center.y = self.view.frame.maxY - 30
            DontShowBut.center.x = self.view.center.x
            
            let moviePath = Bundle.main.path(forResource: "MedTerIt", ofType: "mp4")
            
            
            if let path = moviePath{
                let url = AVPlayer(url: URL(fileURLWithPath: path))
                
                self.player = AVPlayer(url: URL(fileURLWithPath: path))
                self.avpController = AVPlayerViewController()
                self.avpController.player = self.player
                avpController.view.frame.size.width = 375
                avpController.view.frame.size.height = 271
                avpController.view.center = self.view.center
                self.addChildViewController(avpController)
                self.view.addSubview((avpController.view)!)
                self.player.play()
            }

        }
        
        
        
    }
    
     
    override func viewDidDisappear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
        
    }

    
    
  
}
