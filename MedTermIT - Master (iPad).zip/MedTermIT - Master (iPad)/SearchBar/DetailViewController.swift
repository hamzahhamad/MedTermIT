import UIKit
import WebKit
import AVKit
import AVFoundation

class DetailViewController: UIViewController, UITextViewDelegate, WKNavigationDelegate, UISearchBarDelegate, UIActionSheetDelegate {

    
    @IBOutlet weak var HeaderBack: UIImageView!
    
    @IBOutlet weak var VIDViewBack: UIView!

    @IBOutlet weak var wvWeb: UIWebView!
    
    @IBAction func WebButton(_ sender: Any) {
        
        if wvWeb.isHidden == true {
            
            
            UIView.animate(withDuration: 2.0, animations: {self.wvWeb.layoutIfNeeded()})
            wvWeb.isHidden = false
            
        } else {
            
            wvWeb.isHidden = true
            
        }
        
        if self.navigationItem.leftBarButtonItem == nil {
            
            self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: self, action: #selector(WebButton(_:)))
            
            tool.image = nil

        } else {
            
            self.navigationItem.leftBarButtonItem = nil
            
        }

        
        
    }
    
    
    @IBOutlet weak var DrawView: UIView!
    
    @IBAction func miniNote(_ sender: Any) {
        
        if DrawView.isHidden == true {
            UIView.animate(withDuration: 0.3, animations: {self.DrawView.layoutIfNeeded()})
            DrawView.isHidden = false
            
        } else {
            
            DrawView.isHidden = true
            UIView.animate(withDuration: 0.3, animations: {self.DrawView.layoutIfNeeded()})
        }
        
        
    }
    
    @IBOutlet weak var miniNoteOut: UIBarButtonItem!
    
    func hideNotes() {
        
        if DrawView.isHidden == true {
            UIView.animate(withDuration: 0.3, animations: {self.DrawView.layoutIfNeeded()})
            DrawView.isHidden = false
            
            tool.image = #imageLiteral(resourceName: "OvalCLEAR")
            
            
            
        } else {
            
            DrawView.isHidden = true
            
            tool.image = nil

        }
        
    }
    
    
    @IBAction func NotesTog(_ sender: Any) {
        
        if DrawView.isHidden == true {
            UIView.animate(withDuration: 0.3, animations: {self.DrawView.layoutIfNeeded()})
            DrawView.isHidden = false
        
            

            
        } else {
            
            DrawView.isHidden = true
            

        }
        
        if self.navigationItem.leftBarButtonItem == nil {
            
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Minimize", style: UIBarButtonItemStyle.plain, target: self, action: #selector(NotesTog(_:)))
        
      

            
        } else {
            
            self.navigationItem.leftBarButtonItem = nil
            
            tool.image = nil
            
            let cleared = self.imageView.image
            
            if cleared == nil {
                let line = UIImageView(frame: CGRect(x: 50, y: 100, width: 200, height: 1))
                line.backgroundColor = UIColor.green
                self.view.addSubview(tool)
                let image = #imageLiteral(resourceName: "search-3-512")
                let ImageName = self.generateRandomStringWithLength(length: 4)
                print(ImageName)
                let fileManager = FileManager.default
                let paths = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(ImageName)
                let imageTOpng = UIImagePNGRepresentation(image)
                fileManager.createFile(atPath: paths as String, contents: imageTOpng, attributes: nil)
                let imagePAth = (self.getDirectoryPath() as NSString).appendingPathComponent(ImageName)
                print(imagePAth)
                
            } else {
                
                let image = self.imageView.image
                let ImageName = self.generateRandomStringWithLength(length: 4)
                print(ImageName)
                let fileManager = FileManager.default
                let paths = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(ImageName)
                let imageTOpng = UIImagePNGRepresentation(image!)
                fileManager.createFile(atPath: paths as String, contents: imageTOpng, attributes: nil)
                let imagePAth = (self.getDirectoryPath() as NSString).appendingPathComponent(ImageName)
                print(imagePAth)
            }
        }
        
        
    }
    var webView: WKWebView!
    
    @IBAction func reportLink(_ sender: Any) {
        
        let email = "reportlink@integral6.com"
        if let url = URL(string: "mailto:\(email)") {
            UIApplication.shared.open(url)
        }
        print("sennnt")
    }
 
    
    
    
/*  @IBAction func webview(_ sender: Any) {
        self.performSegue(withIdentifier: "WebSegue", sender: self)

    }
*/
    
    
    @IBOutlet weak var VideoError: UIImageView!
    
    //from prev controller
    var dataModel:Model!
    
    var videoURL: NSURL!
    
    
    //IBOutlets
    @IBOutlet weak var imageTermLabel: UITextView!
    @IBOutlet weak var DefinitionLabel: UITextView!
    @IBOutlet weak var TypesLabel: UITextView!
    @IBOutlet weak var wv: UIWebView!
    
    override open var shouldAutorotate: Bool {
        
        return false
        
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask {
        return .portrait
    }
    
    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation {
        return .portrait
    }

    
    var tool: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        wvWeb.isHidden = true
        
        let webURLn = dataModel.imageLink as String
        wvWeb.loadRequest(URLRequest(url: URL(string: webURLn)!))
      
        
        // Do any additional setup after loading the view.
 
        //////
        
        DrawView.isHidden = true
        
        self.navigationItem.leftBarButtonItem = nil
        
        
        
        Save.text = "Save"
        Cleared.text = "Clear"
        Eraser.text = "Erase"
       
        
        tool = UIImageView()
        tool.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
        tool.image = nil
        self.view.addSubview(tool)

        
        
        self.Label.text = dataModel.imageTerm
        
        let Labels = dataModel.imageTerm
     
        // Command to retrieve the terms image and display it when the notes page appears
        
        do {
            // Get the directory contents urls (including subfolders urls)
            // filter the directory contents for a specific extension and choose the name at the end of the URL
            let imagePAth = (self.getDirectoryPath() as NSString).appendingPathComponent(dataModel.imageTerm + ".jpg")
            self.imageView.image = UIImage(contentsOfFile: imagePAth)
            
        }

        
        //////
        
        
       /* wv.allowsPictureInPictureMediaPlayback = true
        wv.allowsLinkPreview = true
        wv.mediaPlaybackRequiresUserAction = true
    */
        wvWeb.allowsPictureInPictureMediaPlayback = true
        wvWeb.allowsLinkPreview = true
        wvWeb.mediaPlaybackRequiresUserAction = true

        
        
        UIDevice.current.setValue(UIInterfaceOrientation.portrait.rawValue, forKey: "orientation")

        UIApplication.shared.statusBarStyle = .lightContent
        
        imageTermLabel.text = dataModel.imageTerm
        DefinitionLabel.text = dataModel.imageDefinition
        TypesLabel.text = dataModel.imageTypes
        
        let videoLink = dataModel.imageVideo
        
        //Youtube or Video embedding
        //body style in the loadHTMLString solves frame center issue
        wv.scrollView.isScrollEnabled = false
        wv.allowsInlineMediaPlayback = true
        wv.isUserInteractionEnabled = true
       
     
        let empty = ""
        if videoLink == "https://vimeo.com/66150307"  {
            
            wv.loadRequest(URLRequest(url: URL(string: videoLink)!))
            VideoError.isHidden = true
            
           

        } else if videoLink == "https://vimeo.com/128707741"  {
            
            wv.loadRequest(URLRequest(url: URL(string: videoLink)!))
            VideoError.isHidden = true
            
            
            
        } else if videoLink == "http://study.com/academy/lesson/what-is-a-database-management-system-purpose-and-function.html" {
            
            wv.loadRequest(URLRequest(url: URL(string: videoLink)!))
            VideoError.isHidden = true
            wv.scrollView.isScrollEnabled = true
        } else if videoLink == "http://www.medicalbillingandcoding.org/intro-to-cpt/"{
            
            wv.loadRequest(URLRequest(url: URL(string: videoLink)!))
            VideoError.isHidden = true
            wv.scrollView.isScrollEnabled = true

        }else if videoLink.range(of:"youtube") != nil{
            VideoError.isHidden = true
            
            let index = videoLink.index(videoLink.startIndex, offsetBy: 32)
            let newid = videoLink.substring(from: index)
            print(newid)
            let http = "https://www.youtube.com/embed/"
            let showInfo = "?showinfo=0?&playsinline=1"
            let newURL = http + newid + showInfo
            print(newURL)
            //wv.loadHTMLString("<body style=\"margin: 0; padding: 0;\"><iframe width=\"760\" height=\"600\" src=\"\(newURL)\" frameborder=\"0\" auto></iframe></body>",baseURL: nil)
            let url = URL(string: "https://www.youtube.com/embed/\(newid)?showinfo=0?&playsinline=1")
            wv.loadRequest(URLRequest(url: url!))
            
        } else if videoLink == empty {
            VideoError.isHidden = false
            
        }else if videoLink ==  "https://vimeo.com/60089665" {
            
            wv.loadRequest(URLRequest(url: URL(string: videoLink)!))
            VideoError.isHidden = true
            
            
        } else if videoLink.range(of:"vimeo") != nil {
           
            let index = videoLink.index(videoLink.startIndex, offsetBy: 18)
            print(index)
            let newid = videoLink.substring(from: index)
            print(newid)
            
            
            
            let embedHTML="<html><head><style type=\"text/css\">body {background-color: transparent;color: white;}</style></head><body style=\"margin:0\"><iframe src=\"//player.vimeo.com/video/\(newid)?autoplay=1&amp;loop=1\" width=\"760\" height=\"660\" frameborder=\"0\" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>";
            
            
            let url: NSURL = NSURL(string: "http://")!
            
            wv.loadHTMLString(embedHTML as String ,baseURL: url as URL)
            
            VideoError.isHidden = true

        }
        
    }
    
    
    
    override func viewDidLayoutSubviews() {
        self.wvWeb.frame = self.view.frame
    }
    
    override func viewDidAppear(_ animated: Bool) {
        self.wvWeb.frame = self.view.frame
        
    }

    
        //Override function to change status bar color
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "NotesSegue"{
            let secondVC: ViewController = segue.destination as! ViewController
            secondVC.recievedString = imageTermLabel.text

        }else if segue.identifier == "WebSegue" {
            
            let third: WebViewController = segue.destination as! WebViewController
            let webURL = dataModel.imageLink
            third.recievedString = webURL
            print(third.recievedString)

        }
    }
    


    override func viewWillDisappear(_ animated: Bool) {
        wv.allowsInlineMediaPlayback = true
        wv.reload()

    }
    
    override func viewDidDisappear(_ animated: Bool) {
        
        wv.allowsInlineMediaPlayback = true
        wv.allowsPictureInPictureMediaPlayback = false
        
        wv.reload()
        
        tool.image = nil

        
          }
    
    
    let context = UIGraphicsGetCurrentContext()
    
    @IBOutlet weak var Eraser: UILabel!
    @IBOutlet weak var Cleared: UILabel!
    @IBOutlet weak var Save: UILabel!
    
    private var path = UIBezierPath()
    private var points = [CGPoint](repeating: CGPoint(), count: 5)
    
    private var controlPoint = 0
    
    
    @IBOutlet weak var Label: UILabel!
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var toolIcon: UIButton!
    var lastPoint = CGPoint.zero
    var swiped = false
    
    var red:CGFloat = 0.0
    var green:CGFloat = 0.0
    var blue:CGFloat = 0.0
    var sizes:CGFloat = 5
    
    var isDrawing = true
    var selectedImage:UIImage!

    func createDirectory(){
        let fileManager = FileManager.default
        let paths = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent("customDirectory")
        if !fileManager.fileExists(atPath: paths){
            try! fileManager.createDirectory(atPath: paths, withIntermediateDirectories: true, attributes: nil)
        }else{
            print("Already dictionary created.")
        }
    }
    
    // Function to call to retrieve directory on the users phone which stores the notes
    func getDirectoryPath() -> String {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths[0]
        return documentsDirectory
    }
    
    func generateRandomStringWithLength(length: Int) -> String {
        
        let jpgExt = ".jpg"
        return(dataModel.imageTerm+jpgExt)
        
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        swiped = false
        
        if let touch = touches.first {
            lastPoint = touch.location(in: self.view)
            
            if (red,green,blue) == (1,1,1) {
                
                tool.image = #imageLiteral(resourceName: "Image-1")
                
            }

        }
        
    }
    
    func drawLines(fromPoint:CGPoint,toPoint:CGPoint) {
        UIGraphicsBeginImageContext(self.view.frame.size)
        imageView.image?.draw(in: CGRect(x: 0, y: 0, width: self.view.frame.width, height: self.view.frame.height))
        let context = UIGraphicsGetCurrentContext()
        context?.move(to: CGPoint(x: fromPoint.x, y: fromPoint.y))
        context?.addLine(to: CGPoint(x: toPoint.x, y: toPoint.y))
        tool.center = toPoint
        
        context?.setBlendMode(CGBlendMode.normal)
        context?.setLineCap(CGLineCap.round)
        context?.setStrokeColor(UIColor(red: red, green: green, blue: blue, alpha: 1.0).cgColor)
        context?.setLineWidth(CGFloat(sizes))
        
        context?.strokePath()
        
        imageView.image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
    }
    
    @IBInspectable public var strokeWidth: CGFloat = 2.0 {
        didSet {
            self.path.lineWidth = strokeWidth
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        swiped = true
        self.controlPoint += 1
        
        if let touch = touches.first {
            let currentPoint = touch.location(in: self.view)
            drawLines(fromPoint: lastPoint, toPoint: currentPoint)
            lastPoint = currentPoint
            
        }
        if (self.controlPoint == 4) {
            self.points[3] = CGPoint(x: (self.points[2].x + self.points[4].x)/2.0, y: (self.points[2].y + self.points[4].y)/2.0)
            self.path.move(to: self.points[0])
            self.path.addCurve(to: self.points[3], controlPoint1:self.points[1], controlPoint2:self.points[2])
            
            self.view.setNeedsDisplay()
            self.points[0] = self.points[3]
            self.points[1] = self.points[4]
            self.controlPoint = 1
        }
        
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if !swiped {
            //   drawLines(fromPoint: lastPoint, toPoint: lastPoint)
        }
        if self.controlPoint == 0 {
            let touchPoint = self.points[0]
            self.path.move(to: CGPoint(x: touchPoint.x-1.0,y: touchPoint.y))
            self.path.addLine(to: CGPoint(x: touchPoint.x+1.0,y: touchPoint.y))
            self.view.setNeedsDisplay()
        } else {
            self.controlPoint = 0
        }
        
    }
    
    
    
    @IBAction func reset(_ sender: AnyObject) {
        //let actionSheet = UIAlertController(title: "Are you sure you want clear the note?", message: "", preferredStyle: .actionSheet)
        //actionSheet.addAction(UIAlertAction(title: "Yes", style: .default, handler: { (_) in
        /*let actionSheetControllerIOS8: UIAlertController = UIAlertController(title: "Please select", message: "Option to select", preferredStyle: .actionSheet)
         let cancelActionButton: UIAlertAction = UIAlertAction(title: "Cancel", style: .cancel) { void in
         print("Cancel")
         }
         actionSheetControllerIOS8.addAction(cancelActionButton)
         
         self.present(actionSheetControllerIOS8, animated: true, completion: nil)*/
        
        
        
        let alert = UIAlertController(title: "Clear and Save?", message: nil, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: { (alert: UIAlertAction) in
            self.imageView.image = nil
            
            let image = #imageLiteral(resourceName: "search-3-512")
            let ImageName = self.generateRandomStringWithLength(length: 4)
            print(ImageName)
            let fileManager = FileManager.default
            let paths = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(ImageName)
            let imageTOpng = UIImagePNGRepresentation(image)
            fileManager.createFile(atPath: paths as String, contents: imageTOpng, attributes: nil)
            let imagePAth = (self.getDirectoryPath() as NSString).appendingPathComponent(ImageName)
            print(imagePAth)
        }))
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertActionStyle.default, handler: nil))
        
        self.present(alert, animated: true, completion: nil)
        
        //  actionSheet.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
        
        //   present(actionSheet, animated: true, completion: nil)
    }
    
    // CHECK TO SEE THIS..........
    @IBAction func save(_ sender: AnyObject) {
        
        /* self.Label.text = self.recievedString
         let Labels = self.recievedString
         
         // Command to retrieve the terms image and display it when the notes page appears
         
         do {
         // Get the directory contents urls (including subfolders urls)
         // filter the directory contents for a specific extension and choose the name at the end of the URL
         let imagePAth = (self.getDirectoryPath() as NSString).appendingPathComponent(Labels+".jpg")
         self.imageView.image = UIImage(contentsOfFile: imagePAth)
         
         }
         
         
         */
        let cleared = self.imageView.image
        
        if cleared == nil {
            let line = UIImageView(frame: CGRect(x: 50, y: 100, width: 200, height: 1))
            line.backgroundColor = UIColor.green
            self.view.addSubview(tool)
            let image = #imageLiteral(resourceName: "search-3-512")
            let ImageName = self.generateRandomStringWithLength(length: 4)
            print(ImageName)
            let fileManager = FileManager.default
            let paths = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(ImageName)
            let imageTOpng = UIImagePNGRepresentation(image)
            fileManager.createFile(atPath: paths as String, contents: imageTOpng, attributes: nil)
            let imagePAth = (self.getDirectoryPath() as NSString).appendingPathComponent(ImageName)
            print(imagePAth)
            
            let alert = UIAlertController(title: "Saved", message: "Successfullys", preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            
            
        } else {
            
            let image = self.imageView.image
            let ImageName = self.generateRandomStringWithLength(length: 4)
            print(ImageName)
            let fileManager = FileManager.default
            let paths = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(ImageName)
            let imageTOpng = UIImagePNGRepresentation(image!)
            fileManager.createFile(atPath: paths as String, contents: imageTOpng, attributes: nil)
            let imagePAth = (self.getDirectoryPath() as NSString).appendingPathComponent(ImageName)
            print(imagePAth)
            
            let alert = UIAlertController(title: "Saved Successfully", message: nil, preferredStyle: UIAlertControllerStyle.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
        
        
    }
    /*      let actionSheet = UIAlertController(title: "Choose an Option", message: "", preferredStyle: .actionSheet)
     actionSheet.addAction(UIAlertAction(title: "Retrieve Last Note", style: .default, handler: { (_) in
     
     
     self.Label.text = self.recievedString
     let Labels = self.recievedString
     
     // Command to retrieve the terms image and display it when the notes page appears
     
     do {
     // Get the directory contents urls (including subfolders urls)
     // filter the directory contents for a specific extension and choose the name at the end of the URL
     let imagePAth = (self.getDirectoryPath() as NSString).appendingPathComponent(Labels+".jpg")
     self.imageView.image = UIImage(contentsOfFile: imagePAth)
     
     }
     
     }))
     
     
     
     actionSheet.addAction(UIAlertAction(title: "Save Note", style: .default, handler: { (_) in
     if let image = self.imageView.image {
     let ImageName = self.generateRandomStringWithLength(length: 4)
     print(ImageName)
     let fileManager = FileManager.default
     let paths = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(ImageName)
     let imageTOpng = UIImagePNGRepresentation(image)
     fileManager.createFile(atPath: paths as String, contents: imageTOpng, attributes: nil)
     let imagePAth = (self.getDirectoryPath() as NSString).appendingPathComponent(ImageName)
     print(imagePAth)
     
     }
     }))
     
     actionSheet.addAction(UIAlertAction(title: "Cancel", style: .default, handler: nil))
     
     present(actionSheet, animated: true, completion: nil)
     
     }
     */
    
    @IBAction func drawLines(_ sender: AnyObject) {
        
        
        if (isDrawing) {
            (red,green,blue) = (1,1,1)
            (sizes) = (40)

        }
        
        
    }
    
    
    
    
    @IBAction func YellowButton(_ sender: Any) {
        (red,green,blue) = (1,1,0)
        (sizes) = (5)
        tool.image = nil

        
    }
    
    @IBAction func BlueButton(_ sender: Any) {
        (red,green,blue) = (0,0,1)
        (sizes) = (5)
        tool.image = nil

    }
    
    
    @IBAction func RedButton(_ sender: Any) {
        (red,green,blue) = (1,0,0)
        
        (sizes) = (5)
        tool.image = nil

        
        
        
        
    }
    
    
    @IBAction func GreenColor(_ sender: Any) {
        (red,green,blue) = (0,1,0)
        (sizes) = (5)
        tool.image = nil

        
        
        
    }
    
    
    
    
    @IBAction func BlackColor(_ sender: Any) {
        
        (red,green,blue) = (0,0,0)
        (sizes) = (5)
        tool.image = nil

        
    }
    
    
   
    
}
