//
//  ViewController2.swift
//  SearchBar
//
//  Created by Hamzah on 2/24/17.
//  Copyright © 2017 Hamzah Hamad. All rights reserved.
//

import Foundation
import UIKit


class NewViewController: UIViewController, UITextViewDelegate, UISearchBarDelegate, UITableViewDelegate, UITableViewDataSource {
    
    
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var leadingconstraint: NSLayoutConstraint!
    
    @IBOutlet weak var menuView: UIView!
    
    var menuShowing = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self


        //Customizing the navigation bar completely and dynamically
        UIApplication.shared.statusBarStyle = .lightContent
        navigationController?.navigationBar.barTintColor = UIColor(red:0.17, green:0.40, blue:1.00, alpha:1.0)
        self.navigationController?.navigationBar.tintColor = UIColor.white
        self.navigationController?.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.white, NSFontAttributeName: UIFont(name: "Avenir", size: 20)!]
        //Menu shadowOpacity shows the shadow, shadowradius increases the shadow radius....
        menuView.layer.shadowOpacity = 1
        menuView.layer.shadowRadius = 5
        self.navigationItem.leftBarButtonItem?.title = "Menu"
        self.navigationItem.leftBarButtonItem?.image = (#imageLiteral(resourceName: "Menu-25"))
        
        
        if((UserDefaults.standard.value(forKey: "favouriteArray")) == nil)
        {
            UserDefaults.standard.setValue(Model.StaticVal.favouriteArray, forKey: "favouriteArray")
        }
        else
        {
            Model.StaticVal.favouriteArray = UserDefaults.standard.value(forKey: "favouriteArray") as! [Int]
        }
        UserDefaults.standard.synchronize()
        self.searchBarSetup()
        let numEntries = dataAry.count
        print(numEntries)

    }
    
    override func viewDidAppear(_ animated: Bool) {
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    @IBAction func Dismiss2(_ sender: Any) {
        leadingconstraint.constant = -280
        menuShowing = !menuShowing
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        leadingconstraint.constant = -280
        menuShowing = false
        
        
        
        
    }
    
    
    
    @IBAction func openMenu(_ sender: Any) {
        
        
        if(menuShowing) {
            
            leadingconstraint.constant = -280
            
            
            
        } else {
            
            leadingconstraint.constant = 0
            
            UIView.animate(withDuration: 0.3, animations: { self.view.layoutIfNeeded()})
            
            
        }
        menuShowing = !menuShowing
        
        
    }
    
    
    let searchBar = UISearchBar(frame: CGRect(x:0,y:0,width:(UIScreen.main.bounds.width),height:80))
    let searchController = UISearchController(searchResultsController: nil)
    
    
    var initialDataAry:[Model] = Model.generateModelArray()
    var dataAry:[Model] = Model.generateModelArray()

    
    
    @IBAction func AllButton(_ sender: Any) {
        if(menuShowing) {
            
            
            
            
            leadingconstraint.constant = -280
            
        } else {
            
            leadingconstraint.constant = 0
            
            UIView.animate(withDuration: 0.3, animations: { self.view.layoutIfNeeded()})
            
        }
        menuShowing = !menuShowing
        
        
    }
    
    
    
    
    
    func searchBarSetup() {
        
        searchBar.showsScopeBar = true
        searchBar.scopeButtonTitles = ["Acronym","Definition","Type"]
        searchBar.selectedScopeButtonIndex = 0
        searchBar.delegate = self
        searchBar.placeholder = "Search any Acronym, Definition, or Type"
        searchBar.showsCancelButton = false
        searchBar.showsBookmarkButton = false
        searchBar.tintColor = UIColor(red: 76/255, green: 127/255, blue: 250/255, alpha: 1.0)
        searchBar.layer.borderWidth = 0
        self.tableView.tableHeaderView = searchBar
        searchBar.barTintColor = UIColor.white
        searchBar.searchBarStyle = UISearchBarStyle.minimal
        searchBar.isTranslucent = false
        
    }
    
    
    
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        if searchText.isEmpty {
            dataAry = initialDataAry
            self.dataAry.sort(by: { $0.imageTerm < $1.imageTerm })
            self.tableView.reloadData()
        }else {
            dataAry = initialDataAry
            filterTableView(ind: searchBar.selectedScopeButtonIndex, text: searchText)
            self.dataAry.sort(by: { $0.imageTerm < $1.imageTerm })
            self.tableView.reloadData()
            
        }
        
    }
    
    
    
    
    func filterTableView(ind:Int,text:String) {
        switch ind {
        case selectedScope20.Term.rawValue:
            //fix of not searching when backspacing
            dataAry = dataAry.filter({ (mod) -> Bool in
                return mod.imageTerm.lowercased().contains(text.lowercased())
            })
            self.tableView.reloadData()
        case selectedScope20.Definition.rawValue:
            //fix of not searching when backspacing
            dataAry = dataAry.filter({ (mod) -> Bool in
                return mod.imageDefinition.lowercased().contains(text.lowercased())
            })
            self.tableView.reloadData()
        case selectedScope20.Types.rawValue:
            //fix of not searching when backspacing
            dataAry = dataAry.filter({ (mod) -> Bool in
                return mod.imageTypes.lowercased().contains(text.lowercased())
            })
            self.tableView.reloadData()
        default:
            print("no type")
        }
    }
    
    
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    
    // MARK: - Table view data source
     func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    
     func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        
        
        if(Model.StaticVal.favouriteArray[indexPath.row] == 1)
        {
            let favorite = UITableViewRowAction(style: .normal, title: "Unfavorite") { action, index in
                
                
                
                DispatchQueue.main.async{
                    self.tableView.reloadData()
                }
                
                self.tableView.reloadData()
                tableView.setEditing(false, animated: true)
                
                if(Model.StaticVal.favouriteArray[indexPath.row] == 1)
                {
                    Model.StaticVal.favouriteArray[indexPath.row] = 0
                }
                    
                else
                {
                    Model.StaticVal.favouriteArray[indexPath.row] = 1
                }
                
                UserDefaults.standard.setValue(Model.StaticVal.favouriteArray, forKey: "favouriteArray")
                UserDefaults.standard.synchronize()
                
            }
            
            favorite.backgroundColor = UIColor(red: 255/255, green: 0/255, blue: 0/255, alpha: 1.0)
            
            
            return [favorite]
            
        }
        else {
            
            let favorite = UITableViewRowAction(style: .normal, title: "Favorite") { action, index in
                
                DispatchQueue.main.async{
                    self.tableView.reloadData()
                }
                
                
                
                self.tableView.reloadData()
                tableView.setEditing(false, animated: true)
                
                if(Model.StaticVal.favouriteArray[indexPath.row] == 1)
                {
                    Model.StaticVal.favouriteArray[indexPath.row] = 0
                }
                    
                else
                {
                    Model.StaticVal.favouriteArray[indexPath.row] = 1
                }
                
                UserDefaults.standard.setValue(Model.StaticVal.favouriteArray, forKey: "favouriteArray")
                UserDefaults.standard.synchronize()
                
            }
            
            favorite.backgroundColor = UIColor(red: 76/255, green: 127/255, blue: 250/255, alpha: 1.0)
            
            
            return [favorite]
            
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // the cells you would like the actions to appear needs to be editable
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        // you need to implement this method too or you can't swipe to display the actions
    }
    
    
     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return dataAry.count
    }
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath) as! TableViewCell1
        
        let model = dataAry[indexPath.row]
        
      //  cell.star.isHidden = true
        cell.TermLbl.text = model.imageTerm
        cell.TypesLbl.text = model.imageTypes
        cell.DefinitionLbl.text = model.imageDefinition
        cell.accessoryType = .none
        
        if Model.StaticVal.favouriteArray[indexPath.row] == 1 {
       //     cell.star.isHidden = false
        }
        
        
        return cell
    }
    
    
    
    //add delegate method for pushing to new detail controller
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        vc.dataModel = dataAry[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
        
    }

    
}
