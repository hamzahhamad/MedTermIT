//
//  TutorialViews.swift
//  MedTermIT
//
//  Created by Hamzah Hamad on 5/25/17.
//  Copyright © 2017 Integral6. All rights reserved.
//

import Foundation
import UIKit

class TutorialOne: UIViewController, UINavigationBarDelegate {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

        print(self.view.frame.maxY)
        
        if self.view.frame.maxY == 568 {
            
            let imageName = "FullSizeRender"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 250, height: 417)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 667  {
            
            let imageName = "FullSizeRender"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 195, height: 325)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 736 {
            
            let imageName = "FullSizeRender"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 300, height: 500)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 1112 {
            
            let imageName = "FullSizeRender"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 546, height: 910)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 1366 {
            
            let imageName = "FullSizeRender"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 696, height: 1160)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 1024 {
            
            let imageName = "FullSizeRender"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 480, height: 800)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        }
        
        UIApplication.shared.statusBarView?.backgroundColor = UIColor(red:0.28, green:0.48, blue:1.00, alpha:1.0)

        
        self.navigationController?.isNavigationBarHidden = true
        
        self.navigationItem.leftBarButtonItem = nil
        
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizerDirection.right
        self.view.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeLeft.direction = UISwipeGestureRecognizerDirection.left
        self.view.addGestureRecognizer(swipeLeft)
        
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeDown.direction = UISwipeGestureRecognizerDirection.down
        self.view.addGestureRecognizer(swipeDown)
        
        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeUp.direction = UISwipeGestureRecognizerDirection.up
        self.view.addGestureRecognizer(swipeUp)
        
    }
    
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
  
    }
    


    
    func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizerDirection.right:
                print("Swiped down")
                    self.navigationItem.leftBarButtonItem?.image = (#imageLiteral(resourceName: "Menu-25"))
                    self.navigationController?.isNavigationBarHidden = false
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "YoImHome") as! ViewControllerMain
                    self.navigationController?.pushViewController(vc, animated: false)
                
            case UISwipeGestureRecognizerDirection.down:
                print("Swiped down")
            case UISwipeGestureRecognizerDirection.left:
                print("Swiped left")
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "One") as! TutorialTwo
            self.navigationController?.pushViewController(vc, animated: false)
                
            case UISwipeGestureRecognizerDirection.up:
                print("Swiped up")
            default:
                break
            }
        }
    }

    

}
extension UIApplication {
    var statusBarView: UIView? {
        return value(forKey: "statusBar") as? UIView
    }
}



class TutorialTwo: UIViewController {
    

   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if self.view.frame.maxY == 667 {
            
            let imageName = "TutMenu"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 250, height: 417)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 568 {
            
            let imageName = "TutMenu"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 195, height: 325)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 736 {
            
            let imageName = "TutMenu"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 300, height: 500)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 1112 {
            
            let imageName = "TutMenu"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 546, height: 910)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 1366 {
            
            let imageName = "TutMenu"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 696, height: 1160)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 1024 {
            
            let imageName = "TutMenu"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 480, height: 800)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        }
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizerDirection.right
        self.view.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeLeft.direction = UISwipeGestureRecognizerDirection.left
        self.view.addGestureRecognizer(swipeLeft)
        
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeDown.direction = UISwipeGestureRecognizerDirection.down
        self.view.addGestureRecognizer(swipeDown)
        
        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeUp.direction = UISwipeGestureRecognizerDirection.up
        self.view.addGestureRecognizer(swipeUp)
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.navigationController?.isNavigationBarHidden = true
        
        self.navigationItem.leftBarButtonItem = nil
    }
    
    func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizerDirection.right:
                print("Swiped down")
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "Zero") as! TutorialOne
                self.navigationController?.pushViewController(vc, animated: false)
            case UISwipeGestureRecognizerDirection.down:
                print("Swiped down")
            case UISwipeGestureRecognizerDirection.left:
                print("Swiped left")
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "Two") as! TutorialThree
                self.navigationController?.pushViewController(vc, animated: false)
            case UISwipeGestureRecognizerDirection.up:
                print("Swiped up")
            default:
                break
            }
        }
    }

    
    
    
    
}




class TutorialThree: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if self.view.frame.maxY == 667 {
            
            let imageName = "TutDetails"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 250, height: 417)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 568 {
            
            let imageName = "TutDetails"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 195, height: 325)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 736 {
            
            let imageName = "TutDetails"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 300, height: 500)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 1112 {
            
            let imageName = "TutDetails"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 546, height: 910)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 1366 {
            
            let imageName = "TutDetails"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 696, height: 1160)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 1024 {
            
            let imageName = "TutDetails"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 480, height: 800)
            
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        }
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizerDirection.right
        self.view.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeLeft.direction = UISwipeGestureRecognizerDirection.left
        self.view.addGestureRecognizer(swipeLeft)
        
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeDown.direction = UISwipeGestureRecognizerDirection.down
        self.view.addGestureRecognizer(swipeDown)
        
        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeUp.direction = UISwipeGestureRecognizerDirection.up
        self.view.addGestureRecognizer(swipeUp)

    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.navigationController?.isNavigationBarHidden = true
        
        self.navigationItem.leftBarButtonItem = nil
    }
    
    func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizerDirection.right:
                print("Swiped down")
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "One") as! TutorialTwo
                self.navigationController?.pushViewController(vc, animated: false)
            case UISwipeGestureRecognizerDirection.down:
                print("Swiped down")
            case UISwipeGestureRecognizerDirection.left:
                print("Swiped left")
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "Three") as! TutorialFour
                self.navigationController?.pushViewController(vc, animated: false)
            case UISwipeGestureRecognizerDirection.up:
                print("Swiped up")
            default:
                break
            }
        }
    }

    
    
    
    
}




class TutorialFour: UIViewController {
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if self.view.frame.maxY == 667 {
            
            let imageName = "TutNotes"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 250, height: 417)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 568 {
            
            let imageName = "TutNotes"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 195, height: 325)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 736 {
            
            let imageName = "TutNotes"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 300, height: 500)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 1112 {
            
            let imageName = "TutNotes"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 546, height: 910)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 1366 {
            
            let imageName = "TutNotes"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 696, height: 1160)
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        } else if self.view.frame.maxY == 1024 {
            
            let imageName = "TutNotes"
            let image = UIImage(named: imageName)
            let imageView = UIImageView(image: image!)
            imageView.frame = CGRect(x: 0, y: 0, width: 480, height: 800)
            
            imageView.center.x = self.view.center.x
            imageView.center.y = self.view.center.y
            view.addSubview(imageView)
            
        }

        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeRight.direction = UISwipeGestureRecognizerDirection.right
        self.view.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeLeft.direction = UISwipeGestureRecognizerDirection.left
        self.view.addGestureRecognizer(swipeLeft)
        
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeDown.direction = UISwipeGestureRecognizerDirection.down
        self.view.addGestureRecognizer(swipeDown)
        
        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(self.respondToSwipeGesture))
        swipeUp.direction = UISwipeGestureRecognizerDirection.up
        self.view.addGestureRecognizer(swipeUp)

    }
    
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.navigationController?.isNavigationBarHidden = true
        
        self.navigationItem.leftBarButtonItem = nil
    }
    
    func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizerDirection.right:
                print("Swiped down")
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "Two") as! TutorialThree
                self.navigationController?.pushViewController(vc, animated: false)
                
            case UISwipeGestureRecognizerDirection.down:
                print("Swiped down")
            case UISwipeGestureRecognizerDirection.left:
                print("Swiped left")
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "YoImHome") as! ViewControllerMain
                self.navigationController?.pushViewController(vc, animated: false)
                self.navigationController?.isNavigationBarHidden = false
                self.navigationItem.leftBarButtonItem?.image = (#imageLiteral(resourceName: "Menu-25"))
            case UISwipeGestureRecognizerDirection.up:
                print("Swiped up")
            default:
                break
            }
        }
    }

    
    
    
}
