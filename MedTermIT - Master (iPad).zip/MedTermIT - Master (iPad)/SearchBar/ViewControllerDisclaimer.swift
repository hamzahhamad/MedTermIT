//
//  ViewControllerDisclaimer.swift
//  MedTermIT
//
//  Created by Hamzah on 3/26/17.
//  Copyright © 2017 Integral6. All rights reserved.
//

import UIKit

class ViewControllerDisclaimer: UIViewController {

    
    @IBAction func Continue(_ sender: Any) {
        
        
        let userdefult = UserDefaults.standard
        
        if userdefult.string(forKey: "SavedDont") == nil {
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "VideoPlayer") as! VideoPlayer
            self.navigationController?.pushViewController(vc, animated: false)
            
        } else {
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoadingScreen") as! ViewControllerLoader
            self.navigationController?.pushViewController(vc, animated: false)

            
        }
      
        
        
    }
    
    
    
        override func viewDidLoad() {
            super.viewDidLoad()
           
            
    }
        
 
        
    
        override func viewDidAppear(_ animated: Bool) {
            self.navigationController?.isNavigationBarHidden = true
            
        }
        
        override func viewDidDisappear(_ animated: Bool) {
            self.navigationController?.isNavigationBarHidden = false
            
        }
        
        
        
        override func didReceiveMemoryWarning() {
            super.didReceiveMemoryWarning()
            // Dispose of any resources that can be recreated.
        }
        
        
        /*
         // MARK: - Navigation
         
         // In a storyboard-based application, you will often want to do a little preparation before navigation
         override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
         // Get the new view controller using segue.destinationViewController.
         // Pass the selected object to the new view controller.
         }
         */
        
}
