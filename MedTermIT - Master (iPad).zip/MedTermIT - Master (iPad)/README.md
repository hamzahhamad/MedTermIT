# SearchBar-in-TableView-Demo
Hello there! This is Sheldon again and welcome back to iOS eTutorials. Today I will talk about the use of the SearchBar in TableView.

The SearchBar will be hard coded in the TableViewHeader. When we change text in the SearchBar, the array of my predefined model objects will be filtered, so that when the TableView is reloaded the filtered data will be reflected into TableView as Well.

The tutorial video on Youtube is available in the link:
https://www.youtube.com/watch?v=TMo7PuggHlc

For more info from me, please feel free to visit my blog site:
http://iosetutorials.com
